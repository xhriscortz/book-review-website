import webbrowser


class Book():
    '''
    Displaying information about a book based on the information provided such
    as book title, description, cover image, and a youtube trailer
    Attributes:
            book_title: a string storing the book title
            book_description: a string storing a description about the book
            poster_image: an image stored
            trailer_youtube: a link storing a YouTube trailer
    '''

    def __init__(
                self, book_title, book_description,
                poster_image, trailer_youtube):
                self.title = book_title
                self.storyline = book_description
                self.poster_image_url = poster_image
                self.trailer_youtube_url = trailer_youtube

    def show_trailer(self):
        """
        Opens browser and allows for book previews to be displayed.
        poster_image is displayed on the frontpage and when it is clicked
        and the trailer_youtube is runned
        """
        webbrowser.open(self.trailer_youtube_url)
