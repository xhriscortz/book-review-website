import fresh_tomatoes
import media


"""
A list is created storing various book details which is later used to
display when the list is called by fresh_tomatoes.open_movies_page(books)
"""


laws_of_power = media.Book(
                "48 Laws of Power",
                "Some powerful secrets of the world",
                "https://pictures.abebooks.com/isbn/9780670881468-us.jpg",
                "https://www.youtube.com/watch?v=SJE3w04zdwk"
                )

art_of_seduction = media.Book(
                "The Art of Seduction",
                "Casanova in many areas, one wouldn't expect",
                "https://images.penguinrandomhouse.com/cover/9780142001196",
                "https://www.youtube.com/watch?v=YstuRGzIPY4"
                    )


strategies_of_war = media.Book(
                "33 Strategies of War",
                "It is composed of discussions and examples on offensive"
                "and defensive strategies from a wide "
                "variety of people and conditions, applying them to social"
                "conflicts such as family quarrels and "
                "business negotiations.",
                "https://i.ytimg.com/vi/9d4dWmKKCpk/maxresdefault.jpg",
                "https://www.youtube.com/watch?v=gsdARf1Q3Ug"
                    )

drop_out_and_get_schooled = media.Book(
                "Drop Out and Get Schooled",
                "The purpose of this book is to start an important"
                "dialogue about college education.",
                "https://i.ytimg.com/vi/dajQqsVAhj4/maxresdefault.jpg",
                "https://www.youtube.com/watch?v=rwqD4V4c-qo"
                        )

mastery = media.Book(
                "Mastery",
                "The book examines the lives of great historical figures",
                "https://i.ytimg.com/vi/ugpnyawZKZo/maxresdefault.jpg",
                "https://www.youtube.com/watch?v=j-QUDT4KOUg"
            )

self_reliance = media.Book(
                "Self Reliance",
                "Man is his own star; and the soul that can"
                "render an honest and a perfect man, commands"
                "all light, all influence, all fate",
                "https://images.gr-assets.com/books/1267957939l/3360759.jpg",
                "https://www.youtube.com/watch?v=33QDZiu6p7E"
                            )

# Storing the book entries in a list
books = [laws_of_power, art_of_seduction, strategies_of_war,
         drop_out_and_get_schooled, mastery, self_reliance]


"""
Calling method open_movies from the fresh_tomatoes file with the list books
as parameter in order to open web browser in order to show book previews.
"""
fresh_tomatoes.open_movies_page(books)
